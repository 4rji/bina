#!/bin/bash

#This is a proto-script for wild-kakuna.sh and is intended to automate the first-15 minutes of tasks for a CCDC competition

#Checks if running as root
oddish_check(){
  if [[ $EUID != 0 ]]; then
    echo "Not running as root...exiting."
    exit 1
  fi
}

#Identifies all accounts with a password login, and prompts the user to update them
barracade(){
  oddish_check
  password_users=$(cat /etc/shadow | grep -wv * | grep -wv ! | cut -d \: -f 1)
  for user in $password_users
    do
      read -p "Enter a password new and unique password for $user: " newpass
      echo "$user:$newpass" | chapasswd
      echo "Password for $user updated."
    done
}

#Applys firewall rules


#Identifies distubution and runs updates for that specific OS
give_rare_candy(){
  oddish_check
  case $(cat /etc/os-release | head -1 | cut -d \" -f 2)
    Pop!_OS)
      apt-get update && apt-get upgrade -y
    Debian_10)
      source rare_candy2.sh -b
  esac
}
